package io.reflectoring.car_rental_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
