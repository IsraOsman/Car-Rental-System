package io.reflectoring.car_rental_system.model;

public abstract class CarType {
    private String carModel;

    public CarType(String carModel){
        this.carModel = carModel;
    }

    public CarType(){

    }

    //add abstract method sig to be used for common functionality

}
