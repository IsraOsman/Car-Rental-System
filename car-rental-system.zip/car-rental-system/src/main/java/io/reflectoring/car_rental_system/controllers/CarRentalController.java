package io.reflectoring.car_rental_system.controllers;


import io.reflectoring.car_rental_system.model.RentalRequest;
import io.reflectoring.car_rental_system.model.RentalResponse;
import io.reflectoring.car_rental_system.service.CarRentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class CarRentalController {
    @Autowired
    CarRentalService carRentalService;

    @GetMapping("/")
    public String get(){
        return "welcome";
    }
    @PostMapping("/rent-car")
    public RentalResponse rentACar(@RequestBody RentalRequest rentalRequest){
        return carRentalService.rentACar(rentalRequest);
    }

}
