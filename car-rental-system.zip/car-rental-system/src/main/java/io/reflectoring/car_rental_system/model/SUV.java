package io.reflectoring.car_rental_system.model;

public class SUV extends CarType{
    public SUV(String name) {
        super(name);
    }
    public SUV(){
        super();
    }
}
