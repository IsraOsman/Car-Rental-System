package io.reflectoring.car_rental_system.model;

public class Van extends CarType{
    public Van(String name) {
        super(name);
    }
    public Van(){
        super();
    }
}
