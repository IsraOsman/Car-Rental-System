package io.reflectoring.car_rental_system;

import io.reflectoring.car_rental_system.controllers.CarRentalController;
import io.reflectoring.car_rental_system.service.CarRentalService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackageClasses = {CarRentalController.class, CarRentalService.class})
public class CarRentalSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarRentalSystemApplication.class, args);
	}

}
