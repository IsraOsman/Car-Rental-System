package io.reflectoring.car_rental_system.model;


public class RentalRequest {
    private String customerId;
    private String customerName;
    private String carId;
    private String pickUpDateAndTime;
    private int days;

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public RentalRequest(String customerId, String customerName,String carId, String pickUpDateAndTime, int days){
        this.customerId = customerId;
        this.customerName = customerName;
        this.carId = carId;
        this.pickUpDateAndTime = pickUpDateAndTime;
        this.days = days;

    }

    public String getPickUpDateAndTime() {
        return pickUpDateAndTime;
    }

    public void setPickUpDateAndTime(String pickUpDateAndTime) {
        this.pickUpDateAndTime = pickUpDateAndTime;
    }

    public String getCarId() {
        return carId;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
}
