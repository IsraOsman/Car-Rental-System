package io.reflectoring.car_rental_system.model;

public class RentalResponse {
    private String carId;
    private Double price;
    private RentalRequestStatus rentalRequestStatus;

    public RentalResponse() {
    }

    public RentalResponse(String carId, Double price, RentalRequestStatus rentalRequestStatus) {
        this.price = price;
        this.carId = carId;
        this.rentalRequestStatus = rentalRequestStatus;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public RentalRequestStatus getRentalRequestStatus() {
        return rentalRequestStatus;
    }

    public void setRentalRequestStatus(RentalRequestStatus rentalRequestStatus) {
        this.rentalRequestStatus = rentalRequestStatus;
    }

    public String getCarId() {
        return carId;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }
}
