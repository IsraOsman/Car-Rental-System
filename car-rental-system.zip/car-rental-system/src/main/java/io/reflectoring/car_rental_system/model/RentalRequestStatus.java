package io.reflectoring.car_rental_system.model;

public enum RentalRequestStatus {
    SUCCESSFUL,
    FAILED;
}
