package io.reflectoring.car_rental_system.service;

import io.reflectoring.car_rental_system.model.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class CarRentalService {
//    The system should allow reservation of a car of a given type at a desired date and time for a given number of days.
//    There are 3 types of cars (sedan, SUV and van).
//    The number of cars of each type is limited.
//    Use unit tests to prove the system satisfies the requirements.

    private List<Customer> customers;
    private List<Rental> rentals;
    private List<Car> cars;


    CarRentalService (){
        customers = new ArrayList<>();
        rentals = new ArrayList<>();
        cars = new ArrayList<>();
    }

    void addCarsDB(){
        Car car = new Car("A1", new SUV(), 50.0);
        Car car1 = new Car("A2", new Sedan(), 50.0);
        Car car2 = new Car("A3", new Van(), 50.0);
        cars.add(car);
        cars.add(car1);
        cars.add(car2);
    }

    void addCustomer(Customer customer){
        customers.add(customer);
    }

    //reserve a car
    public RentalResponse rentACar(RentalRequest rentalRequest){
        //Add cars to be stored asumming in database
        addCarsDB();
        addCustomer(new Customer(rentalRequest.getCustomerId(), rentalRequest.getCustomerName()));
        RentalResponse response = new RentalResponse();

        //Check Car availability
        Car matchingCar = cars.stream()
                .filter(c -> c.getCarId().equals(rentalRequest.getCarId()))
                .toList().get(0);

        if(!Objects.isNull(matchingCar) && matchingCar.isAvailable()){
            matchingCar.rent();
            rentals.add(new Rental(new Customer(rentalRequest.getCarId(), rentalRequest.getCustomerName()), matchingCar, rentalRequest.getDays(), rentalRequest.getPickUpDateAndTime()));
            response.setCarId(rentalRequest.getCarId());
            response.setRentalRequestStatus(RentalRequestStatus.SUCCESSFUL);
        } else {
            response.setRentalRequestStatus(RentalRequestStatus.FAILED);
        }

        return response;

    }

}


