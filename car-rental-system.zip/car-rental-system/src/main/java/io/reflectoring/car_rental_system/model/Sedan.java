package io.reflectoring.car_rental_system.model;

public class Sedan extends CarType{

    public Sedan(String name) {
        super(name);
    }

    public Sedan(){
        super();
    }
}
